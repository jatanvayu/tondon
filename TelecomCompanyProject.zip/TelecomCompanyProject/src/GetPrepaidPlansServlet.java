

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.techm.interfaces.PlanDao;

import com.techm.implementations.PlanImpl;

import com.techm.classes.Plan;


public class GetPrepaidPlansServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private PlanDao planDao;

	
	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("DisplayFAQServlet Servlet Init invoked!");
		planDao=new PlanImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ArrayList<Plan> prepaidplanList=planDao.getPrepaidPlans();
		HttpSession session=request.getSession();
		session.setAttribute("prepaidplanList", prepaidplanList);
		
		RequestDispatcher rd=request.getRequestDispatcher("/viewprepaidplans.jsp");
		rd.forward(request,response );
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
