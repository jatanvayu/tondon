package com.techm.classes;

import java.util.Date;

public class Bill {
	private long mobileNo;
	private int amount;
	private int status;
	private String username;
	private int planId;
	
	public Bill(long mobileNo, int amount, int status,String username,int planId) {
		super();
		this.mobileNo = mobileNo;
		this.amount = amount;
		this.status = status;
		this.username = username;
		this.planId = planId;
	}
	
	
	
	
	public Bill() {
		// TODO Auto-generated constructor stub
	}




	public long getMobileNo() {
		return mobileNo;
	}




	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}




	public int getAmount() {
		return amount;
	}




	public void setAmount(int amount) {
		this.amount = amount;
	}




	public int getStatus() {
		return status;
	}




	public void setStatus(int status) {
		this.status = status;
	}




	public String getUsername() {
		return username;
	}




	public void setUsername(String username) {
		this.username = username;
	}




	public int getPlanId() {
		return planId;
	}




	public void setPlanId(int planId) {
		this.planId = planId;
	}




	@Override
	public String toString() {
		return "Bill [mobileNo=" + mobileNo + ", amount=" + amount
				+ ", status=" + status + ", username=" + username + ", planId="
				+ planId + "]";
	}


	

	
	
	
	

	
	
	
	

}
