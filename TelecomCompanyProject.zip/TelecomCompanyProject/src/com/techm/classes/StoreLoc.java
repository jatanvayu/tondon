package com.techm.classes;

public class StoreLoc {
	
	private int locationId;
	private String city;
	private String addresses;
	
	
	public StoreLoc(int locationId, String city, String addresses) {
		super();
		this.locationId = locationId;
		this.city = city;
		this.setAddresses(addresses);
	}
	
	
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getCity() {
		return city;
	}
	public void setLocation(String city) {
		this.city = city;
	}
	
	
	


	@Override
	public String toString() {
		return "StoreLoc [locationId=" + locationId + ", city=" + city
				+ ", addresses=" + addresses + "]";
	}


	public String getAddresses() {
		return addresses;
	}


	public void setAddresses(String addresses) {
		this.addresses = addresses;
	}
	
	
	

}
