package com.techm.classes;

public class WriteToUs {
	
	
	
	/*private int faqId;*/
	private String query;
	private int status;
	private String answer;
	private String username;
	private String usercity;
	private String useremail;
	private String contact;
	
	
	
	
	public WriteToUs() {
		super();
	}




	public WriteToUs(/*int faqId,*/ String query, int status, String answer,
			String username, String usercity, String useremail, String contact) {
		super();
		/*this.faqId = faqId;*/
		this.query = query;
		this.status = status;
		this.answer = answer;
		this.username = username;
		this.usercity = usercity;
		this.useremail = useremail;
		this.contact = contact;
	}




	/*public int getFaqId() {
		return faqId;
	}




	public void setFaqId(int faqId) {
		this.faqId = faqId;
	}*/




	public String getQuery() {
		return query;
	}




	public void setQuery(String query) {
		this.query = query;
	}




	public int getStatus() {
		return status;
	}




	public void setStatus(int status) {
		this.status = status;
	}




	public String getAnswer() {
		return answer;
	}




	public void setAnswer(String answer) {
		this.answer = answer;
	}




	public String getUsername() {
		return username;
	}




	public void setUsername(String username) {
		this.username = username;
	}




	public String getUsercity() {
		return usercity;
	}




	public void setUsercity(String usercity) {
		this.usercity = usercity;
	}




	public String getUseremail() {
		return useremail;
	}




	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}




	public String getContact() {
		return contact;
	}




	public void setContact(String contact) {
		this.contact = contact;
	}




	@Override
	public String toString() {
		return "WriteToUs [ query=" + query + ", status="
				+ status + ", answer=" + answer + ", username=" + username
				+ ", usercity=" + usercity + ", useremail=" + useremail
				+ ", contact=" + contact + "]";
	}
	
		
	
	
	
}
