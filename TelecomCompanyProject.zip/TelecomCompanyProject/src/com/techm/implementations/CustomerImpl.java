package com.techm.implementations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Connection;
import com.techm.classes.Customer;
import com.techm.connection.jdbcConnection;
import com.techm.interfaces.CustomerDao;



public class CustomerImpl implements CustomerDao{

	jdbcConnection jcon = new jdbcConnection();
	Connection con;

	public boolean addCustomer(Customer customer) {
		String SQL="insert into customer values(?,?,?,?,?)";
		boolean isAdded=false;
	
		if(customer.getUsername()!=null && customer.getPassword()!=null && customer.getCity()!=null && customer.getEmail()!=null && customer.getCellNo()!=null)
		{
			
			System.out.println("all entries made!");
			con=(Connection) jcon.getConnection();
			
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, customer.getUsername());
				ps.setString(2, customer.getPassword());
				
				
				ps.setString(5, customer.getCity());
				ps.setString(6, customer.getEmail());
				ps.setString(7, customer.getCellNo());
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isAdded=true;
					System.out.println("Customer Added!");
				}
				else
				{
					System.out.println("Customer not Added!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				con=(Connection)jcon.closeConnection();
			}
		
		}
		else
		{
			System.out.println("Entries left!");
			isAdded=false;
			
		}
			
		
		return isAdded;
	}

	public boolean validateCustomer(Customer customer) {
		String SQL="select * from customer where username=? and password=?";
		boolean isValid=false;
		con=(Connection) jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, customer.getUsername());
			ps.setString(2, customer.getPassword());
			ResultSet rs=ps.executeQuery();
			//validation 
			if(rs.next())
			{
				isValid=true;
			}
			
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			con=(Connection)jcon.closeConnection(); 
		}
		
		return isValid;
		
	}
	
	
}
