package com.techm.implementations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;








import java.sql.Connection;
import com.techm.interfaces.WriteToUsDao;
import com.techm.classes.Customer;
import com.techm.classes.WriteToUs;
import com.techm.connection.jdbcConnection;

public class WriteToUsImpl implements WriteToUsDao{

	jdbcConnection jcon = new jdbcConnection();
	Connection con;

	
	public boolean setQuery(String query, int status,
			String username, String usercity, String useremail, String contact) {
		
		WriteToUs wtu=new WriteToUs();
		
		String SQL="insert into write_to_us values(?,?,?,?,?,?)";
		boolean isAdded=false;
		con=(Connection) jcon.getConnection();
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				
				ps.setString(1, query);
				ps.setInt(2, 0);
				ps.setString(3, wtu.getUsername());
				ps.setString(4, wtu.getUsercity());
				ps.setString(5, wtu.getUseremail());
				ps.setString(6, wtu.getContact());
				
				
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isAdded=true;
					System.out.println("Query Added!");
				}
				else
				{
					System.out.println("Query not Added!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				con=(Connection)jcon.closeConnection();
			}
		
		return isAdded;
		
	}

	public ArrayList<WriteToUs> getAllQueries() {
		String SQL="select query from write_to_us where status=1";
		ArrayList<WriteToUs> queryList=new ArrayList<WriteToUs>();
		WriteToUs writeToUs=null;
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				writeToUs=new WriteToUs();
				
				
				writeToUs.setQuery(rs.getString("query"));
				
				queryList.add(writeToUs);
			}
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}
		return queryList;
		
	}

	public boolean submitAnswer(String username, String answer) {
		String SQL="update write_to_us set answer=?,status=1 where username=?";
		boolean isAdded=false;
		jcon.getConnection();
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, answer);
				ps.setString(2, username);
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isAdded=true;
					System.out.println("Answer submitted!");
				}
				else
				{
					System.out.println("Answer not submitted!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				jcon.closeConnection();
			}
		
		return isAdded;
		
	}

	
}
