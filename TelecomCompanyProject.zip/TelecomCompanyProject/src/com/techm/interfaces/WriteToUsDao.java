package com.techm.interfaces;

import java.util.ArrayList;

import com.techm.classes.Customer;
import com.techm.classes.WriteToUs;


public interface WriteToUsDao {
	
	public boolean setQuery(String query, int status,
			String username, String usercity, String useremail, String contact);
	
	public boolean submitAnswer(String username,String answer);
	public ArrayList<WriteToUs> getAllQueries();
	
}
