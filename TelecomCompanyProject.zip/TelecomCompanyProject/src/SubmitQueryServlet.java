

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.techm.interfaces.WriteToUsDao;

import com.techm.implementations.WriteToUsImpl;
import com.techm.classes.Customer;

public class SubmitQueryServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private WriteToUsDao writeToUsDao;

	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("QuerySubmitServlet Servlet Init invoked!");
		writeToUsDao=new WriteToUsImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("QuerySubmitServlet doGet invoked!");
		
		String query=request.getParameter("Query");
		String username=request.getParameter("Username");
		String city=request.getParameter("city");
		String email=request.getParameter("Email");
		String contact=request.getParameter("Contact");
		
		System.out.println(username);
		
		System.out.println(query);
		
		boolean isAdded=false;
		HttpSession session=request.getSession();
		isAdded=writeToUsDao.setQuery(query, 0, username, city, email, contact);
		
		
		if(isAdded=true)
		{
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			out.println("<center><h2>Query Submitted!</h2>");
		
		/*	
			RequestDispatcher rd=request.getRequestDispatcher("/login_popup-pack/writetous.jsp");
			rd.include(request,response );*/
		}
		else
		{
			System.out.println("Query submit Error!");
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
